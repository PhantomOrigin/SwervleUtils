// Self-patching background service worker. Replaces the old design (a
// static rules.json + patched-bundle.js/patched-terrainview.js committed to
// the extension, refreshed only by manually re-running tools/patch-bundle.mjs
// after every swervle.com redeploy) with one that re-derives and re-patches
// itself at runtime, using the exact same logic — see tools/patch-logic.mjs,
// which this file and the CLI both import, specifically so the two never
// drift apart.
//
// How the redirect actually works now: instead of `declarativeNetRequest`
// redirecting to a packaged `extensionPath` file (fixed at install time,
// unwritable afterward), this builds the patched sources fully in memory,
// encodes each as a `data:` URL, and registers those as DYNAMIC rules via
// `chrome.declarativeNetRequest.updateDynamicRules()` — an API call, not a
// file write, so it can run again any time without needing a new extension
// version. Confirmed empirically (a throwaway probe extension) that a
// dynamic rule can carry a `data:` URL sized well beyond what's needed here
// (~850KB main bundle, ~340KB TerrainView chunk, both base64-encoded) and
// Chrome honors it end-to-end.
//
// What this can't do, and why the CLI (tools/patch-bundle.mjs) still exists:
// MV3's default extension CSP blocks dynamic code evaluation (`eval`,
// `new Function`, and — as far as this could determine without an explicit
// test that would need its own CSP relaxation — likely `import()` of a
// `data:`/`blob:` module too), so this can't re-run the CLI's ESM-integrity
// check (parse-and-link the patched output, catching things like a
// private-class-field insertion that split a statement) on itself before
// shipping it. The safety net that DOES apply here is the same one that's
// always protected the manual process: makePatcher requires an anchor to
// match EXACTLY ONCE before touching anything, so a stale/ambiguous anchor
// skips just that one patch rather than risking a corrupting insertion —
// see patch-logic.mjs. A genuinely bad insertion slipping through that would
// need a person to notice and fix in patch-logic.mjs either way, exactly as
// before; what's automated away is the routine case (hashes/identifiers
// reshuffled, shape unchanged), which is the vast majority of redeploys.
//
// When this runs:
//   - Extension install/update, and browser/service-worker startup.
//   - Immediately, whenever a content script reports (via the
//     "srv:pageLoaded" message) that the live page's script filename
//     doesn't match what's currently registered — this can't help the page
//     that just triggered it (that page's own script request was already
//     decided before its content script could run and report anything);
//     it fixes things for the NEXT load, and content.js tells the player
//     to refresh when this happens. No recurring timer beyond that — a
//     service worker that's gone idle (Chrome suspends these after ~30s of
//     inactivity) only wakes up for an event it's listening for anyway, so
//     the two triggers above already cover every point where staleness
//     would actually matter.

import { patchLiveBundles } from "./tools/patch-logic.mjs";

const ORIGIN = "https://swervle.com";
const MAIN_RULE_ID = 1;
const TV_RULE_ID = 2;
const CSP_RULE_ID = 3;

function uint8ToBase64(bytes) {
  let binary = "";
  const chunkSize = 0x8000; // avoid a stack-overflow-sized argument list to String.fromCharCode
  for (let i = 0; i < bytes.length; i += chunkSize) {
    binary += String.fromCharCode(...bytes.subarray(i, i + chunkSize));
  }
  return btoa(binary);
}

// `btoa` alone throws on any character outside Latin-1, which a bundle full
// of UI strings can easily contain — encoding through UTF-8 bytes first
// (and declaring that charset on the data: URL) avoids that entirely,
// rather than just working by luck on the current bundle's specific content.
function toDataUrl(text) {
  const bytes = new TextEncoder().encode(text);
  return `data:text/javascript;charset=utf-8;base64,${uint8ToBase64(bytes)}`;
}

// Same wildcard-by-hash-prefix approach the old rules.json used: a pure
// hash-bump redeploy with no code changes (common) still matches without
// needing this to run again first — though it runs proactively anyway (see
// triggers above), this just means a request that slips in before that
// finishes still hits the most recent rule rather than none at all.
function mainBundleUrlFilter(mainFilename) {
  return `||swervle.com/assets/${mainFilename.replace(/-[^-.]+\.js$/, "-*.js")}`;
}

let inFlightPatchCycle = null;

// Runs one full fetch+derive+patch+register cycle. Concurrent callers (e.g.
// several swervle.com tabs reporting staleness at once) share the same
// in-flight attempt rather than each starting a redundant fetch.
function runPatchCycle() {
  if (inFlightPatchCycle) return inFlightPatchCycle;
  inFlightPatchCycle = (async () => {
    const startedAt = Date.now();
    try {
      const { mainFilename, mainSrc, tvFilename, tvSrc, names, results } = await patchLiveBundles(ORIGIN, console);

      await chrome.declarativeNetRequest.updateDynamicRules({
        removeRuleIds: [MAIN_RULE_ID, TV_RULE_ID, CSP_RULE_ID],
        addRules: [
          {
            id: MAIN_RULE_ID,
            priority: 1,
            action: { type: "redirect", redirect: { url: toDataUrl(mainSrc) } },
            condition: { urlFilter: mainBundleUrlFilter(mainFilename), resourceTypes: ["script"] },
          },
          {
            id: TV_RULE_ID,
            priority: 1,
            action: { type: "redirect", redirect: { url: toDataUrl(tvSrc) } },
            condition: { urlFilter: `||swervle.com/assets/${tvFilename}`, resourceTypes: ["script"] },
          },
          // swervle.com's own CSP sends a `script-src` allowlist (its
          // origin plus specific ad/analytics/Cloudflare domains) with no
          // `data:` in it — confirmed directly from a real "Refused to
          // load the script 'data:...'" console error. That's what a
          // browser is SUPPOSED to do; the two redirect rules above
          // substitute a `data:` URL for the real one, but the resulting
          // request still has to clear the page's own CSP afterward, and
          // this site's does not allow that scheme for scripts. Since MV3
          // gives extensions no way to rewrite a response BODY (only
          // headers/redirects — see this file's own top comment on why
          // `data:` delivery was chosen over that in the first place),
          // stripping the CSP header on the top-level document is the only
          // available lever. This does trade away whatever XSS protection
          // that header was providing — acceptable for a personal
          // extension the user already trusts to rewrite the site's own
          // code wholesale, but worth knowing it's happening.
          {
            id: CSP_RULE_ID,
            priority: 1,
            action: {
              type: "modifyHeaders",
              responseHeaders: [{ header: "content-security-policy", operation: "remove" }],
            },
            condition: { urlFilter: "||swervle.com/", resourceTypes: ["main_frame"] },
          },
        ],
      });

      const failedPatches = results.filter((r) => !r.ok).map((r) => `${r.file}/${r.name}`);
      const state = {
        ok: true,
        mainFilename,
        tvFilename,
        names,
        failedPatches,
        lastRunAt: startedAt,
        lastError: null,
      };
      await chrome.storage.local.set({ srvPatchState: state });
      setBadge(failedPatches.length > 0 ? "warn" : "ok");
      console.log(
        `[srv self-patch] applied against ${mainFilename} — ${results.length - failedPatches.length}/${results.length} patches ok` +
          (failedPatches.length > 0 ? `, failed: ${failedPatches.join(", ")}` : "")
      );
      return state;
    } catch (err) {
      const state = { ok: false, lastRunAt: startedAt, lastError: err?.message ?? String(err) };
      // Deliberately does NOT clear any previously-registered dynamic
      // rules — if this was a transient fetch failure, the last known-good
      // patched bundle staying active is strictly better than falling back
      // to no redirect (which would silently drop every hook this
      // extension provides) or, worse, leaving a half-registered pair.
      const prior = await chrome.storage.local.get("srvPatchState");
      await chrome.storage.local.set({ srvPatchState: { ...prior.srvPatchState, ...state } });
      setBadge("error");
      console.error("[srv self-patch] failed:", err);
      return state;
    } finally {
      inFlightPatchCycle = null;
    }
  })();
  return inFlightPatchCycle;
}

function setBadge(status) {
  const text = { ok: "", warn: "!", error: "X" }[status] ?? "";
  chrome.action?.setBadgeText?.({ text });
  chrome.action?.setBadgeBackgroundColor?.({ color: status === "error" ? "#c0392b" : "#e6a23c" });
}

chrome.runtime.onInstalled.addListener(() => runPatchCycle());
chrome.runtime.onStartup.addListener(() => runPatchCycle());

// content.js (isolated world, has chrome.runtime access — unlike srv-main.js
// which runs in the page's own MAIN world) reports the live page's actual
// script filename on every load — this, plus install/startup above, is the
// entire trigger set (see this file's top comment for why there's no
// recurring timer). A redeploy gets caught the moment anyone next opens the
// site, fixed for the NEXT load, with content.js telling the player to
// refresh.
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg?.type !== "srv:pageLoaded") return undefined;
  (async () => {
    const { srvPatchState } = await chrome.storage.local.get("srvPatchState");
    const isCurrent = srvPatchState?.ok && srvPatchState.mainFilename === msg.liveMainFilename;
    if (isCurrent) {
      sendResponse({ staleOnLoad: false });
      return;
    }
    // Stale (or this is the very first load this session, before any patch
    // cycle has ever completed) — either way, THIS page's own script
    // request already happened with whatever was (or wasn't) registered
    // at the time, so it can't be retroactively fixed. Kick off a fresh
    // cycle for next time and let the caller know a reload is what's
    // actually needed.
    const result = await runPatchCycle();
    sendResponse({ staleOnLoad: true, rePatchOk: result.ok, failedPatches: result.failedPatches ?? [] });
  })();
  return true; // keep the message channel open for the async sendResponse above
});

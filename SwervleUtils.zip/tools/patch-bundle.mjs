#!/usr/bin/env node
// CLI wrapper around tools/patch-logic.mjs (the portable derive/patch core —
// see that file for the actual identifier-derivation regexes and the
// rationale behind the wildcarded-anchor approach). Historically this was
// the ONLY way to refresh the extension's patches after a swervle.com
// redeploy — you had to notice something broke, then re-run this by hand.
//
// As of the self-patching background service worker (see background.js),
// the extension now re-derives and re-patches itself at runtime — on
// install/startup, and whenever a content script reports the live site's
// bundle filename doesn't match what's currently active — via
// `chrome.declarativeNetRequest.updateDynamicRules()` redirecting to
// `data:` URLs it builds in memory. It never touches this repo's files.
//
// This script still exists for two things the extension's own background
// worker deliberately doesn't do:
//   - Local/offline testing against a saved bundle (pass two file paths).
//   - Writing patched-bundle.js/patched-terrainview.js to disk so they can
//     actually be inspected/diffed, rather than only ever existing as an
//     in-memory data: URL inside a running browser.
// It is NOT required for the extension to keep working after a redeploy
// anymore — that's the whole point of background.js.
//
// Usage:
//   node tools/patch-bundle.mjs
//     Fetches everything live from swervle.com and writes
//     patched-bundle.js/patched-terrainview.js into the extension
//     directory, purely for inspection — the running extension doesn't
//     read these files at all anymore.
//
//   node tools/patch-bundle.mjs <main.js> <terrainview-chunk.js>
//     Offline mode: patches two already-downloaded files instead of
//     fetching. Useful for testing against a saved bundle.
// ============================================================================

import { readFileSync, writeFileSync } from "node:fs";
import { fileURLToPath, pathToFileURL } from "node:url";
import { dirname, join } from "node:path";
import {
  rewriteRelativeChunkRefs,
  makePatcher,
  deriveIdentifiers,
  patchMainBundle,
  patchTerrainViewChunk,
  discoverAndFetchMainBundle,
  fetchTerrainViewChunk,
} from "./patch-logic.mjs";

const __dirname = dirname(fileURLToPath(import.meta.url));
const OUT_DIR = join(__dirname, "..");

const ORIGIN = "https://swervle.com";
const [, , mainInArg, terrainViewInArg] = process.argv;
const OFFLINE = Boolean(mainInArg && terrainViewInArg);

// Sanity-checks a patched output file by actually letting Node's ESM loader
// parse AND link it — not just `node --check`, which only does a syntax
// pass and has been observed to pass clean on code containing a genuine
// "Private field must be declared in an enclosing class" defect (a
// linking-time error, not a syntax error). Class-body private-field
// validation only happens during linking, which only a real
// parse-and-link attempt (like a dynamic import()) exercises.
//
// The patched files legitimately contain `import("https://swervle.com/...")`
// calls meant for a browser, which Node's loader can never resolve — so a
// SUCCESSFUL run of this always ends in one specific, benign error *after*
// parsing/linking already completed. Anything else (a SyntaxError, or an
// error before that expected point) means this patch run corrupted the
// file, and is treated as a hard failure. (background.js can't run this
// exact check — see its own comment on why — which is part of why this
// script stays useful as a manual verification path.)
async function verifyEsmIntegrity(fileLabel, absPath) {
  try {
    await import(pathToFileURL(absPath).href + `?verify=${Date.now()}`);
    console.log(`✓ [${fileLabel}] parsed and linked cleanly (imported with no error at all — unexpected but fine).`);
    return true;
  } catch (err) {
    const isExpectedNetworkError =
      err instanceof Error &&
      !(err instanceof SyntaxError) &&
      /scheme in: file and data|Cannot find module|ENOTFOUND|fetch failed/i.test(err.message);
    if (isExpectedNetworkError) {
      console.log(`✓ [${fileLabel}] parsed and linked cleanly (only failed on an expected unresolvable https:// import).`);
      return true;
    }
    console.error(
      `✗ [${fileLabel}] FAILED to parse/link — this patch run likely corrupted the file's structure ` +
        `(e.g. an anchor split a multi-statement declaration, as happened once before):\n` +
        `  ${err.constructor.name}: ${err.message}`
    );
    return false;
  }
}

async function main() {
  const results = [];

  let mainFilename, mainRawSrc;
  if (OFFLINE) {
    mainRawSrc = readFileSync(mainInArg, "utf8");
    mainFilename = mainInArg.split(/[\\/]/).pop();
    console.log(`Offline mode: using local file ${mainInArg}`);
  } else {
    ({ mainFilename, mainRawSrc } = await discoverAndFetchMainBundle(ORIGIN));
    console.log(`Discovered live main bundle: ${mainFilename}`);
  }

  const mainRewritten = rewriteRelativeChunkRefs(ORIGIN, "main bundle", mainRawSrc);
  const names = deriveIdentifiers(mainRewritten, mainRawSrc);
  console.log("Derived identifiers:", names);
  const { patchedSrc: mainSrc } = patchMainBundle(mainRewritten, mainRawSrc, names, ORIGIN, results);

  writeFileSync(join(OUT_DIR, "patched-bundle.js"), mainSrc, "utf8");
  console.log(`Patched main bundle written to patched-bundle.js (${mainSrc.length} bytes).`);

  let tvFilename, tvRawSrc;
  if (OFFLINE) {
    tvRawSrc = readFileSync(terrainViewInArg, "utf8");
    tvFilename = terrainViewInArg.split(/[\\/]/).pop();
  } else {
    if (!names.rvChunkPath) throw new Error("Could not locate the RV/TerrainView chunk's import path in the main bundle.");
    ({ tvFilename, tvRawSrc } = await fetchTerrainViewChunk(ORIGIN, names.rvChunkPath));
    console.log(`Discovered live RV/TerrainView chunk: ${tvFilename}`);
  }

  const tvRewritten = rewriteRelativeChunkRefs(ORIGIN, "TerrainView chunk", tvRawSrc);
  const { patchedSrc: tvSrc } = patchTerrainViewChunk(tvRewritten, results);

  writeFileSync(join(OUT_DIR, "patched-terrainview.js"), tvSrc, "utf8");
  console.log(`Patched TerrainView chunk written to patched-terrainview.js (${tvSrc.length} bytes).`);

  const mainOk = await verifyEsmIntegrity("main bundle", join(OUT_DIR, "patched-bundle.js"));
  const tvOk = await verifyEsmIntegrity("TerrainView chunk", join(OUT_DIR, "patched-terrainview.js"));

  const failed = results.filter((r) => !r.ok);
  console.log(`\n${results.length - failed.length}/${results.length} patches applied.`);
  if (failed.length > 0) {
    console.log("Needs re-deriving (site likely changed structurally, not just renamed identifiers):");
    for (const r of failed) console.log(`  - [${r.file}] ${r.name}`);
    console.log(
      "\nBoth output files were still written with every OTHER patch applied — " +
        "only the features tied to the anchors above are affected. Note: the running extension " +
        "re-derives this independently at runtime (see background.js) — these written files are " +
        "for inspection only and aren't read by the extension."
    );
    process.exitCode = 1;
  }
  if (!mainOk || !tvOk) {
    console.error(
      "\n⚠ At least one output file failed ESM integrity verification. An anchor likely inserted " +
        "code into the middle of an existing statement (see patch-logic.mjs's patch #2 comment history " +
        "for a real past example). If this reproduces from the LIVE site (not just an offline test file), " +
        "background.js is building the exact same patched text right now via the identical shared logic " +
        "in patch-logic.mjs — but it CAN'T run this check itself (MV3's default extension CSP blocks " +
        "dynamic code evaluation, which this linking-time check fundamentally requires), so this manual " +
        "run is the only way to catch it. The affected patch needs re-deriving in patch-logic.mjs."
    );
    process.exitCode = 1;
  }
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
